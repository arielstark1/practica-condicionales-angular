export interface BlockableUI {
    getBlockableElement(): HTMLElement;
}